package com.muhammadfurqon.made_sub1.ui;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.muhammadfurqon.made_sub1.model.Movie;
import com.muhammadfurqon.made_sub1.R;

import com.squareup.picasso.Picasso;

public class DetailMovie extends AppCompatActivity {

    public static final String EXTRA_MOVIE = "extra_movie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit_detail);

        //get data Movie send by MainActivity with EXTRA_MOVIE
        Movie selectedMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);

        if (selectedMovie != null) {
            ImageView imgFoto = findViewById(R.id.iv_detail_photo);
            Picasso.get().load(selectedMovie.getPhoto()).fit().centerCrop().into(imgFoto);

            TextView txtNama = findViewById(R.id.tv_detail_name);
            txtNama.setText(selectedMovie.getName());

            TextView txtDesc = findViewById(R.id.tv_detail_description);
            txtDesc.setText(selectedMovie.getDescription());

            TextView txtRilis = findViewById(R.id.tv_detail_release);
            txtRilis.setText("(" + selectedMovie.getRelease_date() + ")");

            TextView txtGenre = findViewById(R.id.tv_detail_genre);
            txtGenre.setText(selectedMovie.getGenre());

            TextView txtRate = findViewById(R.id.tv_detail_rating);
            txtRate.setText("Rating: " + String.valueOf(selectedMovie.getRating()) + "/10");
        }
        setActionBarTitle("MOVIE CATALOGUE");
    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }
}